let currentSlide = 0;

function showPopup(type) {
    const popup = document.getElementById('popup');
    const popupMessage = document.getElementById('popup-message');
    popup.style.display = 'block';
    popup.classList.add('show');

    if (type === 'apk') {
        popupMessage.textContent = 'You clicked the Download APK button!';
    } else if (type === 'apple') {
        popupMessage.textContent = 'You clicked the Download on the App Store button!';
    }
}

function showComingSoonPopup() {
    const comingSoonPopup = document.getElementById('coming-soon-popup');
    comingSoonPopup.style.display = 'block';
    comingSoonPopup.classList.add('show');
}

function showConfirmationPopup() {
    const confirmationPopup = document.getElementById('confirmation-popup');
    confirmationPopup.style.display = 'block';
    confirmationPopup.classList.add('show');
}

function closePopup(popupId) {
    const popup = document.getElementById(popupId);
    popup.style.display = 'none';
    popup.classList.remove('show');
}

function changeSlide(n) {
    const slides = document.querySelector('.slides');
    const totalSlides = document.querySelectorAll('.slide').length;
    currentSlide = (currentSlide + n + totalSlides) % totalSlides;
    slides.style.transform = `translateX(${-currentSlide * 100}%)`;
}

// Initial setup for slider
document.addEventListener('DOMContentLoaded', function() {
    const slides = document.querySelector('.slides');
    slides.style.transform = `translateX(${-currentSlide * 100}%)`;
});
